CinemaQB - Static demo site (free, client-only)

Features included:
- Bottom menu with Favorites, Categories, Profile (Profile opens admin login)
- Categories / Genres list and per-genre filtering
- Admin login with password: 13822 (handled client-side; for demo only)
- Admin panel lets you upload poster (uses local FileReader), set metadata, and save movie to browser localStorage
- Each movie opens a detailed modal page with description, metadata, and a player with selectable qualities (1080/720/480)
- Language toggle (Persian/English) and Day/Night theme
- Comments per movie stored in localStorage
- All data is client-side; edits persist in your browser only (localStorage)

How to use:
1. Upload the files to a static host (GitHub Pages / Netlify).
2. Open index.html in the browser.
3. To add a movie: click Profile -> enter password 13822 -> upload poster (optional) and fill fields -> Save Movie.
4. Poster files are stored locally (base64) and will persist in your browser only.

Security & notes:
- Admin password and admin tools are client-side only for demo purposes — not secure for production.
- For production you need a real backend, authentication, and secure storage for media.

Enjoy! - I prepared this package for you.
